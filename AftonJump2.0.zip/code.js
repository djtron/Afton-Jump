

var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["a9c7fb27-9799-4507-8c9a-b0e56203922e","aafc3456-7760-45c6-9847-7d556cb007c2","860208c7-d6bd-46a0-84d6-014775fe80db","e04c8cd1-c5f2-42b2-a0b4-5f90276405f7","5a9c0751-286e-491e-a131-1b22df56897d","daaec058-0dba-448d-a9bd-9f52ec8be6da","1c505950-c16a-47db-adad-ae473180d23f","97288862-515b-4cd5-9957-3eb8b619a963","1a824926-badc-4b1d-9b0e-92c22c02cc2b","59181ad5-6acb-429e-96b5-542e0c3920cf","26323199-6ff7-4a49-b1fe-8f7fb6ffbd97","5c8a42fc-5963-4eee-857a-9706d94dfdb8","a39dd10a-1784-47d4-a97d-ecb1f8c9fb0f","c37b247d-47ca-46ed-98e6-e84ae02d756b","81a5c352-81bc-4082-ab2e-4a39c47a52b1","8e485b45-002d-467d-a618-c55a02c9b88e","638327e3-90b2-491d-b9c3-e180b768b96a"],"propsByKey":{"a9c7fb27-9799-4507-8c9a-b0e56203922e":{"name":"left","sourceUrl":null,"frameSize":{"x":129,"y":243},"frameCount":2,"looping":true,"frameDelay":12,"version":"9BsWnSpMMNSoLuGqk46nJChQ4JpMaX0r","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":258,"y":243},"rootRelativePath":"assets/a9c7fb27-9799-4507-8c9a-b0e56203922e.png"},"aafc3456-7760-45c6-9847-7d556cb007c2":{"name":"eleft","sourceUrl":null,"frameSize":{"x":129,"y":243},"frameCount":2,"looping":true,"frameDelay":12,"version":"K4L46o9RiKWO5A2dbx6PK02okCxmF.7P","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":258,"y":243},"rootRelativePath":"assets/aafc3456-7760-45c6-9847-7d556cb007c2.png"},"860208c7-d6bd-46a0-84d6-014775fe80db":{"name":"right","sourceUrl":null,"frameSize":{"x":129,"y":243},"frameCount":2,"looping":true,"frameDelay":12,"version":"fRNW2A0otAViUA3HYe5JozNFctyKWS4V","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":258,"y":243},"rootRelativePath":"assets/860208c7-d6bd-46a0-84d6-014775fe80db.png"},"e04c8cd1-c5f2-42b2-a0b4-5f90276405f7":{"name":"eright","sourceUrl":null,"frameSize":{"x":129,"y":243},"frameCount":2,"looping":true,"frameDelay":12,"version":"W.yFoLKbScSL8hCX4MelzDChJ4PJchPG","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":258,"y":243},"rootRelativePath":"assets/e04c8cd1-c5f2-42b2-a0b4-5f90276405f7.png"},"5a9c0751-286e-491e-a131-1b22df56897d":{"name":"wall","sourceUrl":null,"frameSize":{"x":480,"y":480},"frameCount":1,"looping":true,"frameDelay":12,"version":"1ZL9ipnzFHomzVY71DuMNs2JUKyxbK9.","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":480,"y":480},"rootRelativePath":"assets/5a9c0751-286e-491e-a131-1b22df56897d.png"},"daaec058-0dba-448d-a9bd-9f52ec8be6da":{"name":"blank","sourceUrl":"assets/api/v1/animation-library/mUlvnlbeZ5GHYr_Lb4NIuMwPs7kGxHWz/category_backgrounds/blank.png","frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":4,"version":"mUlvnlbeZ5GHYr_Lb4NIuMwPs7kGxHWz","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/api/v1/animation-library/mUlvnlbeZ5GHYr_Lb4NIuMwPs7kGxHWz/category_backgrounds/blank.png"},"1c505950-c16a-47db-adad-ae473180d23f":{"name":"gameback","sourceUrl":null,"frameSize":{"x":728,"y":410},"frameCount":1,"looping":true,"frameDelay":12,"version":"5zJWnkw_YJ2tbrNjsyBxgFPyfMrAySld","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":728,"y":410},"rootRelativePath":"assets/1c505950-c16a-47db-adad-ae473180d23f.png"},"97288862-515b-4cd5-9957-3eb8b619a963":{"name":"looser","sourceUrl":null,"frameSize":{"x":1200,"y":795},"frameCount":2,"looping":true,"frameDelay":30,"version":"YuBDPq7.PMQudK13qTTe1FIP6ksEMyFa","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":1200,"y":1590},"rootRelativePath":"assets/97288862-515b-4cd5-9957-3eb8b619a963.png"},"1a824926-badc-4b1d-9b0e-92c22c02cc2b":{"name":"start_button_1","sourceUrl":null,"frameSize":{"x":800,"y":252},"frameCount":1,"looping":true,"frameDelay":12,"version":"PnnTle32T9M86NAfo6Riips7ujFWa0N5","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":800,"y":252},"rootRelativePath":"assets/1a824926-badc-4b1d-9b0e-92c22c02cc2b.png"},"59181ad5-6acb-429e-96b5-542e0c3920cf":{"name":"cred","sourceUrl":"assets/v3/animations/ZLpcWnU0j0xzvHqCKtNPFZ4IIchksPicfFtwL4sj7Mk/59181ad5-6acb-429e-96b5-542e0c3920cf.png","frameSize":{"x":500,"y":280},"frameCount":1,"looping":true,"frameDelay":4,"version":"DniieZvmKsAViTqK48Qva2yb6XcMmoNP","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":500,"y":280},"rootRelativePath":"assets/v3/animations/ZLpcWnU0j0xzvHqCKtNPFZ4IIchksPicfFtwL4sj7Mk/59181ad5-6acb-429e-96b5-542e0c3920cf.png"},"26323199-6ff7-4a49-b1fe-8f7fb6ffbd97":{"name":"chhese.png_1","sourceUrl":"assets/v3/animations/ZLpcWnU0j0xzvHqCKtNPFZ4IIchksPicfFtwL4sj7Mk/26323199-6ff7-4a49-b1fe-8f7fb6ffbd97.png","frameSize":{"x":480,"y":480},"frameCount":1,"looping":true,"frameDelay":4,"version":"LZFmC1_rEGli3dgGMIH49MFoVsPrt7uy","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":480,"y":480},"rootRelativePath":"assets/v3/animations/ZLpcWnU0j0xzvHqCKtNPFZ4IIchksPicfFtwL4sj7Mk/26323199-6ff7-4a49-b1fe-8f7fb6ffbd97.png"},"5c8a42fc-5963-4eee-857a-9706d94dfdb8":{"name":"back","sourceUrl":"assets/v3/animations/ZLpcWnU0j0xzvHqCKtNPFZ4IIchksPicfFtwL4sj7Mk/5c8a42fc-5963-4eee-857a-9706d94dfdb8.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":4,"version":"xrSl6fhFASgYgACOsQHMvvlaS96T7A9K","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/v3/animations/ZLpcWnU0j0xzvHqCKtNPFZ4IIchksPicfFtwL4sj7Mk/5c8a42fc-5963-4eee-857a-9706d94dfdb8.png"},"a39dd10a-1784-47d4-a97d-ecb1f8c9fb0f":{"name":"question","sourceUrl":null,"frameSize":{"x":1092,"y":996},"frameCount":1,"looping":true,"frameDelay":12,"version":"c_9BqbmfaUW8Y1AuUmU2KcUC6vLrztDU","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":1092,"y":996},"rootRelativePath":"assets/a39dd10a-1784-47d4-a97d-ecb1f8c9fb0f.png"},"c37b247d-47ca-46ed-98e6-e84ae02d756b":{"name":"howto","sourceUrl":"assets/v3/animations/ZLpcWnU0j0xzvHqCKtNPFZ4IIchksPicfFtwL4sj7Mk/c37b247d-47ca-46ed-98e6-e84ae02d756b.png","frameSize":{"x":480,"y":480},"frameCount":1,"looping":true,"frameDelay":4,"version":"xtnkMtkm5AyqM5cdaZNF9Yf6ft_eQl5Q","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":480,"y":480},"rootRelativePath":"assets/v3/animations/ZLpcWnU0j0xzvHqCKtNPFZ4IIchksPicfFtwL4sj7Mk/c37b247d-47ca-46ed-98e6-e84ae02d756b.png"},"81a5c352-81bc-4082-ab2e-4a39c47a52b1":{"name":"title.png","sourceUrl":"assets/v3/animations/ZLpcWnU0j0xzvHqCKtNPFZ4IIchksPicfFtwL4sj7Mk/81a5c352-81bc-4082-ab2e-4a39c47a52b1.png","frameSize":{"x":236,"y":160},"frameCount":1,"looping":true,"frameDelay":4,"version":"wGZn3ZxMGUmg01O.auDohMPyFHtKIB.W","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":236,"y":160},"rootRelativePath":"assets/v3/animations/ZLpcWnU0j0xzvHqCKtNPFZ4IIchksPicfFtwL4sj7Mk/81a5c352-81bc-4082-ab2e-4a39c47a52b1.png"},"8e485b45-002d-467d-a618-c55a02c9b88e":{"name":"sped","sourceUrl":null,"frameSize":{"x":467,"y":26},"frameCount":1,"looping":true,"frameDelay":12,"version":"OlzywaCAVD4QFNA5fI5mPzkthmB1mDc7","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":467,"y":26},"rootRelativePath":"assets/8e485b45-002d-467d-a618-c55a02c9b88e.png"},"638327e3-90b2-491d-b9c3-e180b768b96a":{"sourceSize":{"x":2001,"y":2000},"frameSize":{"x":667,"y":500},"frameCount":11,"frameDelay":3,"name":"jumpscare","sourceUrl":null,"size":60560,"version":"iWv9BZP40XQlsF0buMLEBAjy4ltFPPYD","categories":[""],"looping":true,"loadedFromSource":true,"saved":true,"rootRelativePath":"assets/638327e3-90b2-491d-b9c3-e180b768b96a.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//Sprites
//
var controlscreen = createSprite(-4000, -4000);
controlscreen.setAnimation("chhese.png_1");
var howtoplay = createSprite(-8000, -8000);
howtoplay.setAnimation("howto");
var home1 = createSprite(-8165, -8160);
home1.setAnimation("back");
home1.scale = 0.25;
var home = createSprite(-4165, -4160);
home.setAnimation("back");
home.scale = 0.25;
var looser = createSprite(3000, 3000);
looser.setAnimation("looser");
looser.scale = 0.6;
var back = createSprite(200, 303);
back.setAnimation("gameback");
var purplg = createSprite(200, 200);
purplg.setAnimation("title.png");
purplg.scale = 1.1;
var start = createSprite(200, 330);
start.setAnimation("start_button_1");
start.scale = 0.3;
var cred = createSprite(80, 440);
cred.setAnimation("cred");
cred.scale = 0.3;
var question = createSprite(350, 437);
question.setAnimation("question");
question.scale = 0.07;
var sped = createSprite(200, 490);
sped.setAnimation("sped");
sped.scale = 0.8;
var player = createSprite(800, 300);
player.setAnimation("left");
player.scale = 0.24;
var enemy1 = createSprite(randomNumber(660, 960), player.y - 75);
enemy1.scale = 0.24;
enemy1.setAnimation("eleft");
var enemy2 = createSprite(randomNumber(660, 960), player.y - 150);
enemy2.scale = 0.24;
enemy2.setAnimation("eleft");
var enemy3 = createSprite(randomNumber(660, 960), player.y - 225);
enemy3.scale = 0.24;
enemy3.setAnimation("eleft");
var enemy4 = createSprite(randomNumber(660, 960), player.y - 300);
enemy4.scale = 0.24;
enemy4.setAnimation("eleft");
var enemy5 = createSprite(randomNumber(660, 960), player.y - 375);
enemy5.scale = 0.24;
enemy5.setAnimation("eleft");
var enemy6 = createSprite(randomNumber(660, 960), player.y - 450);
enemy6.scale = 0.24;
enemy6.setAnimation("eleft");
enemy1.velocityX = randomNumber(-30, 30);
enemy2.velocityX = randomNumber(-30, 30);
enemy3.velocityX = randomNumber(-30, 30);
enemy4.velocityX = randomNumber(-30, 30);
enemy5.velocityX = randomNumber(-30, 30);
enemy6.velocityX = randomNumber(-30, 30);
var wall = createSprite(10000, 330);
wall.setAnimation("blank");
wall.scale = 1;
var int = createSprite(200, 200);
int.setAnimation("title.png");
int.scale = 0.93;
var scare = createSprite(3000, 3000);
scare.setAnimation("blank");

//variables
var hc = 0;
var walk = 1;
var oof = 1;
var move = 1;
var pause = 1;
var no = 1;
var up = 2;
var ded = 1;
var levels = 0;
var nope = 1;
var uistop = 0;
var e1 = randomNumber(0.1, 6) / 10;
var e2 = randomNumber(0.1, 6) / 10;
var e3 = randomNumber(0.1, 6) / 10;
var e4 = randomNumber(0.1, 6) / 10;
var e5 = randomNumber(0.1, 6) / 10;
var e6 = randomNumber(0.1, 6) / 10;
//miscellaneous
camera.x=200;
camera.y=303;
playSound("assets/better.mp3", true);
drawSprites();

//Functions
function draw() {
  if (enemy1.velocityX == 0) {
    enemy1.velocityX = 2;
  }
  if (enemy2.velocityX == 0) {
    enemy2.velocityX = 2;
  }
  if (enemy3.velocityX == 0) {
    enemy3.velocityX = 2;
  }
  if (enemy4.velocityX == 0) {
    enemy4.velocityX = 2;
  }
  if (enemy5.velocityX == 0) {
    enemy5.velocityX = 2;
  }
  if (enemy6.velocityX == 0) {
    enemy6.velocityX = 2;
  }
  if (levels > hc) {
    hc = levels;
  }
  if (mousePressedOver(looser)) {
    camera.x=200;
    camera.y=303;
    player.x = 800;
    player.y = 300;
    walk = 1;
    oof = 1;
    move = 1;
    pause = 1;
    no = 1;
    up = 2;
    ded = 1;
    levels = 0;
    nope = 1;
    uistop = 0;
    enemy1.y = player.y-75;
    enemy2.y = player.y-150;
    enemy3.y = player.y-225;
    enemy4.y = player.y-300;
    enemy5.y = player.y-375;
    enemy6.y = player.y-450;
  }
  if (mousePressedOver(question)) {
    playSound("assets/category_digital/power_up.mp3", false);
    camera.x = -8000;
    camera.y = -8000;
  }
  if (mousePressedOver(home)) {
    playSound("assets/category_digital/power_down_2.mp3", false);
    camera.x=200;
    camera.y=303;
  }
  if (mousePressedOver(home1)) {
    playSound("assets/category_digital/power_down_2.mp3", false);
    camera.x=200;
    camera.y=303;
  }
  if (mousePressedOver(cred)) {
    playSound("assets/category_digital/hop.mp3", false);
    camera.x = -4000;
    camera.y = -4000;
  }
  int.x = wall.x;
  int.y = wall.y;
  if (ded == 2) {
    oof = 3;
    dedr();
  }
  if (pause >= player.y) {
    pause = -9999999;
    player.velocityY = 0;
    player.y = player.y + 3;
  }
  if ((225 + player.y) <= enemy1.y) {
    enemy1.y = player.y - 225;
    enemy1.x = randomNumber(660, 960);
  }
  if ((225 + player.y) <= enemy2.y) {
    enemy2.y = player.y - 225;
    enemy2.x = randomNumber(660, 960);
  }
  if ((225 + player.y) <= enemy3.y) {
    enemy3.y = player.y - 225;
    enemy3.x = randomNumber(660, 960);
  }
  if ((225 + player.y) <= enemy4.y) {
    enemy4.y = player.y - 225;
    enemy4.x = randomNumber(660, 960);
  }
  if ((225 + player.y) <= (enemy5.y)) {
    enemy5.y = player.y - 225;
    enemy5.x = randomNumber(660, 960);
  }
  if ((225 + player.y) <= (enemy6.y)) {
    enemy6.y = player.y - 225;
    enemy6.x = randomNumber(660, 960);
  }
  if ((enemy1.x) <= 680) {
    enemy1.velocityX = up + e1;
    enemy1.setAnimation("eright");
  }
  if (enemy1.x >= 948) {
    enemy1.velocityX = -1 * up - e1;
    enemy1.setAnimation("eleft");
  }
  if ((enemy2.x) <= 680) {
    enemy2.velocityX = e2 + up;
    enemy2.setAnimation("eright");
  }
  if (enemy2.x >= 948) {
    enemy2.velocityX = -1 * up - e2;
    enemy2.setAnimation("eleft");
  }
  if ((enemy3.x) <= 680) {
    enemy3.velocityX = up + e3;
    enemy3.setAnimation("eright");
  }
  if (enemy3.x >= 948) {
    enemy3.velocityX = -1 * up - e3;
    enemy3.setAnimation("eleft");
  }
  if ((enemy4.x) <= 680) {
    enemy4.velocityX = up + e4;
    enemy4.setAnimation("eright");
  }
  if (enemy4.x >= 948) {
    enemy4.velocityX = -1 * up - e4;
    enemy4.setAnimation("eleft");
  }
  if ((enemy5.x) <= 680) {
    enemy5.velocityX = up + e5;
    enemy5.setAnimation("eright");
  }
  if (enemy5.x >= 948) {
    enemy5.velocityX = -1 * up - e5;
    enemy5.setAnimation("eleft");
  }
  if ((enemy6.x) <= 680) {
    enemy6.velocityX = up + e6;
    enemy6.setAnimation("eright");
  }
  if (enemy6.x >= 948) {
    enemy6.velocityX = -1 * up - e6;
    enemy6.setAnimation("eleft");
  }
  if (no == 2) {
    lick();
  }
  if (oof == 3) {
    monk();
  }
  if (mousePressedOver(start) && walk != 2) {
    playSound("assets/category_digital/startup.mp3", false);
    wall.y = camera.y-480;
    walk = 2;
  }
  if (camera.x >= 800) {
    oof = 3;
  } else {
    if (oof == 2) {
      move = move + 0.7;
      camera.x=camera.x + move;
    }
  }
  if (walk == 2) {
    truck();
  }
  // draw background

  // update sprites

  drawSprites();
  floors();
  ui();
}
//death screen
function dedr() {
  setTimeout(function() {
    if (camera.x == 3000) {
      playSound("assets/arblled.mp3", false);
      scare.setAnimation("jumpscare");
    }
  }, 66666);
  uistop = 1000000;
  oof = 4;
  camera.x=3000;
  camera.y=3000;
}
//game mechanics
function monk() {
  if (player.isTouching(enemy1)) {
    playSound("assets/Fnaf-4-Bite-Sound-Effect--TubeRipper.com-.mp3", false);
    ded = 2;
  }
  if (player.isTouching(enemy2)) {
    playSound("assets/Fnaf-4-Bite-Sound-Effect--TubeRipper.com-.mp3", false);
    ded = 2;
  }
  if (player.isTouching(enemy3)) {
    playSound("assets/Fnaf-4-Bite-Sound-Effect--TubeRipper.com-.mp3", false);
    ded = 2;
  }
  if (player.isTouching(enemy4)) {
    playSound("assets/Fnaf-4-Bite-Sound-Effect--TubeRipper.com-.mp3", false);
    ded = 2;
  }
  if (player.isTouching(enemy5)) {
    playSound("assets/Fnaf-4-Bite-Sound-Effect--TubeRipper.com-.mp3", false);
    ded = 2;
  }
  if (player.isTouching(enemy6)) {
    playSound("assets/Fnaf-4-Bite-Sound-Effect--TubeRipper.com-.mp3", false);
    ded = 2;
  }
  camera.x=810;
  camera.y=player.y;
  if (player.x >= 680 && (keyDown("a") || keyDown("left"))) {
    player.setAnimation("left");
    player.x = player.x + -4;
  }
  if (948 >= player.x && (keyDown("d") || keyDown("right"))) {
    player.setAnimation("right");
    player.x = player.x + 4;
  }
  if (pause <= (player.y)) {
    no = 1;
    if ((keyWentDown("w") || (keyWentDown("space") || keyWentDown("up"))) && 0 == player.velocityY) {
      playSound("assets/category_digital/jump_7.mp3", false);
      levels = levels + 1;
      up = up + 0.035;
      no = 2;
    }
  }
}
//miscellaneous debugging 
function lick() {
  player.velocityY = player.velocityY + -6;
  pause = player.y - 75;
}
//game start
function truck() {
  wall.setAnimation("wall");
  wall.x = camera.x;
  if (nope==2) {
    setTimeout(function() {
      wall.velocityY = -8;
    }, 2000);
  } else {
    if (wall.y >= 300) {
      wall.velocityY = 0;
      oof = 2;
      nope = 2;
    } else {
      wall.velocityY = 8;
    }
  }
}
//background
function floors() {
  background("SlateBlue");
  fill("Sienna");
  rect(660, -9999, 300, 999999);
  fill("SeaGreen");
  rect(400, 330, 2500, 200);
  fill("Maroon");
  rect(2500, 2800, 1000, 1000);
  fill("LightSlateGrey");
  rect(660, enemy1.y + 25, 300, 8);
  rect(660, enemy2.y + 25, 300, 8);
  rect(660, enemy3.y + 25, 300, 8);
  rect(660, enemy4.y + 25, 300, 8);
  rect(660, enemy5.y + 25, 300, 8);
  rect(660, enemy6.y + 25, 300, 8);
  drawSprites();
}
//UI (duh)
function ui() {
  if (oof == 3) {
    textFont("Arial");
    fill("white");
    textSize(30);
    text(levels, camera.x+167+uistop, camera.y-140+uistop);
    text(hc, (camera.x+-178)+uistop, camera.y-140+uistop);
    textSize(10);
    text("LEVELS", camera.x+155+uistop, camera.y-170+uistop);
    textSize(30);
    text("HC", (camera.x+-195)+uistop, camera.y-170+uistop);
    textSize(20);
    text("CLICK ANYWHERE TO RESTART", 2853, 2850);
    textSize(30);
    text("LEVELS", 2850, 3100);
    text("HC", 3070, 3100);
    textSize(40);
    text(levels, 2896, 3150);
    text(hc, 3080, 3150);
  }
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
